# imports
import os, psutil, math
from datetime import datetime

# constants
C = 299792458.0


# ---------------------------------------------------------------------------------------

# functions

# distance between two planets
def distance():
    # globals
    global planet1
    global planet2
    global distance

    # starting conditions
    arc = False
    acondition = False
    conjunction = False
    planet2 = "earth"
    planet1 = input("Enter the planet to determine distance relative to earth: ")
    currentdatestandard = datetime.today()
    currentdate = currentdatestandard.timestamp()  # convert to seconds

    for x in range(num_planets):
        if planetname[x] == planet1:
            planet1 = planetname[x]
            radius_planet1 = orbitalradius[x]
            period_planet1 = orbitalperiod[x]
            year_o = year[x]
            month_o = month[x]
            day_o = day[x]
        elif planetname[x] == planet2:
            radius_planet2 = orbitalradius[x]
            period_planet2 = orbitalperiod[x]

    # calculate circumfrence
    circumfrence_planet1 = 2.0 * (math.pi) * radius_planet1
    circumfrence_planet2 = 2.0 * (math.pi) * radius_planet2

    # convert period to seconds
    period_planet1 = period_planet1 * (86400.0)
    period_planet2 = period_planet2 * (86400.0)

    # calculate planet speeds
    speed_planet1 = circumfrence_planet1 / period_planet1
    speed_planet2 = circumfrence_planet2 / period_planet2

    # find time passed
    timeelapsed = currentdate - (year_o * 31540000.0 + month_o * 2628000.0 + day_o * 86400)

    # calculate arc lengths
    arc_planet1 = timeelapsed * speed_planet1
    arc_planet2 = timeelapsed * speed_planet2
    while arc == False:
        if arc_planet1 > circumfrence_planet1:
            arc_planet1 = arc_planet1 - circumfrence_planet1
        else:
            arc = True

    # calculate angle
    angle_planet1 = arc_planet1 / radius_planet1
    angle_planet2 = arc_planet2 / radius_planet2

    while acondition == False:
        if angle_planet1 > 360:
            angle_planet1 - 360.0
        else:
            acondition = True

    if angle_planet1 > angle_planet2:
        angle = angle_planet1 - angle_planet2
    elif angle_planet1 < angle_planet2:
        angle = angle_planet2 - angle_planet1

    if angle >= 173 and angle <= 187:
        conjunction = True

    # calculate distance between planets
    distance = int(math.sqrt(
        math.pow(radius_planet1, 2) + math.pow(radius_planet2, 2) - 2.0 * radius_planet1 * radius_planet2 * math.cos(
            angle)))

    # print result
    if conjunction == True:
        print("There is a solar conjunction at this time, transmission impossible.")

    print("The distance between " + str(planet1) + " and " + str(planet2) + " is " + str(round(distance, 2)) + " m.")


# latency between planets
def latency():
    latency = (distance / C) * 1000.0
    print("The latency between " + str(planet1) + " and " + str(planet2) + " is " + str(latency) + " ms.")


# configuration mode
def con():
    # globals
    global data
    global num_planets
    global planetname
    global orbitalradius
    global orbitalperiod
    global year
    global month
    global day

    data = [[], [], [], [], [], []]
    num_planets = 0
    configure_data = True
    planetname = []
    orbitalradius = []
    orbitalperiod = []
    year = []
    month = []
    day = []

    while configure_data == True:
        options = input(
            "Would you like to add an entry(a), view entries (v), update an entry(u) delete an entry (d) or go back (b)?:\n")

        if options == "a":
            add_planets = int(input("How many planets do you want to add?: "))

            for x in range(add_planets):
                planetnameV = str(input("Enter your planet name: "))
                planetname.append(planetnameV)

                orbitalradiusV = float(input("What is the radius of orbit (m): "))
                orbitalradius.append(orbitalradiusV)

                orbitalperiodV = float(input("Enter orbital period (days): "))
                orbitalperiod.append(orbitalperiodV)

                if planetnameV != "earth":

                    yearV = float(input("Enter the year of last opposition: "))
                    year.append(yearV)

                    monthV = float(input("Enter the month of last opposition: "))
                    month.append(monthV)

                    dayV = float(input("Enter the day of last opposition: "))
                    day.append(dayV)
                else:
                    yearZ = 0.0
                    year.append(yearZ)
                    monthZ = 0.0
                    month.append(monthZ)
                    dayZ = 0.0
                    day.append(dayZ)

            data = [planetname, orbitalradius, orbitalperiod, year, month, day]

            num_planets += add_planets


        elif options == "v":
            print(data)

        elif options == "u":
            update_planet = input("Enter the name of the planet you want to update?")
            for x in range(num_planets):
                if planetname[x] == update_planet:
                    planetname[x] = update_planet
                    orbitalradius[x] = float(input("Enter the radius of orbit (m): "))
                    orbitalperiod[x] = float(input("Enter the orbital period (days): "))

                    if planetname[x] != "earth":
                        year[x] = float(input("Enter the year of last opposition: "))
                        month[x] = float(input("Enter the month of last opposition: "))
                        day[x] = float(input("Enter the day of last opposition: "))

                    break

        elif options == "d":
            delete_planet = input("Enter the name of the planet you want to delete: ")
            for x in range(num_planets):
                if planetname[x] == delete_planet and x < num_planets - 1:
                    planetname[x] = planetname[x + 1]
                    orbitalradius[x] = orbitalradius[x + 1]
                    orbitalperiod[x] = orbitalperiod[x + 1]
                    year[x] = year[x + 1]
                    month[x] = month[x + 1]
                    day[x] = day[x + 1]
                elif x == num_planets - 1:
                    planetname.pop()
                    orbitalradius.pop()
                    orbitalperiod.pop()
                    year.pop()
                    month.pop()
                    day.pop()
        elif options == "b":
            configure_data = False
        else:
            print("Error. Enter a valid option.")


# calculation mode
def cal():
    distance()
    latency()


def main():
    # determine mode
    program = True
    while program == True:
        mode = int(input("What mode would you like to use configuration, calculation or quit (1/2/3)?:\n"))

        while (mode != 1 or mode != 2 or mode != 3):

            if mode == 1 or mode == 2 or mode == 3:
                break

            print("Please enter correct mode")
            mode = int(input("What mode would you like to use configuration, calculation or quit (1/2/3)?:\n"))

        if mode == 1:
            con()
        elif mode == 2:
            cal()
        elif mode == 3:
            program = False


# ---------------------------------------------------------------------------------------

main()

# percent cpu used
print("\n\n\nPercentage of CPU used: " + str(psutil.cpu_percent()))

# memory used in bytes
process = psutil.Process(os.getpid())
print("Bytes of memory used: " + str(process.memory_info().rss))




