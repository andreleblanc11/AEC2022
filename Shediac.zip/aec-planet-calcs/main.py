"""
Main script to start the application.
"""

from controller import main

main()